﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Exercise 2 Solution
/// </summary>
public class PrintFavoriteGames : MonoBehaviour
{
	/// <summary>
	/// Start is called before the first frame update
	/// </summary>
	void Start()
	{
        print("DiRT Rally");
        print("Assetto Corsa");
        print("Project CARS");
    }
}
